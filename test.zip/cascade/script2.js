function toggleId(parentId) {
	var parentEl = document.querySelector('[data-id="' + parentId + '"]');
	var state = parseInt(parentEl.dataset.state)
	// toggle the state
	if (state === 1) {
		state=0;
	}
	else {
		state=1;
	}

	// update the state
	parentEl.dataset.state = state;
	// update the visibility state (always since its being focused)
	parentEl.dataset.visible = 1;
	
	console.log("toggled [parent: " + parentId + ",value:" + state + "]");

	// DEBUG
	parentEl.children[1].innerHTML = "currentState: " + parentEl.dataset.state + " visible: " +  parentEl.dataset.visible + " prevBeforeCollapse: " + parentEl.dataset.prev;
	
	// perform the toggle
	toggleState(parentEl, state, true, parentId);
}

function toggleState(parentEl, state, firstLevel, rootId)
{
	// get the list of elements who has the matching parent ID
	var children = document.querySelectorAll('[data-parent="' + parentEl.dataset.id + '"]');
	
	if (children.length == 0)
	{
		return;
	}
	
	// ensure the list is not empty
	// loop through those elements (they are considered children)
	for (var i = 0; i < children.length; ++i)
	{
		var currentChild = children[i];
		// get the current syle
		var currentChildStyle = currentChild.style;
		
		// close all
		if (state === 0)
		{
			currentChildStyle.display = "none";
			currentChild.dataset.prev = currentChild.dataset.visible;
			// save a snapshot of the current expanded elements
		}
		else
		{
			if (firstLevel === true)
			{
				currentChild.dataset.visible = state;
				currentChildStyle.display = "";
			}
			else
			{
				if (currentChild.dataset.prev === 1)
				{
					currentChild.dataset.visible = 1;
					currentChild.dataset.prev = 0;
					currentChild.display = "";
				}
				else
				{
					currentChild.dataset.visible = 0;
					currentChild.dataset.prev = 1;
					currentChild.display = "none";
				}
			}
		}
		
		// DEBUG
		console.log(currentChild.dataset.id + " - currentState: " + currentChild.dataset.state + " visible: " +  currentChild.dataset.visible + " prevBeforeCollapse: " + currentChild.dataset.prev);
		currentChild.children[1].innerHTML = "currentState: " + currentChild.dataset.state + " visible: " +  currentChild.dataset.visible + " prevBeforeCollapse: " + currentChild.dataset.prev;
		
		// ensure the child has an ID
		if (!!currentChild.dataset.id )
		{
			var childParentId = currentChild.dataset.parent;
			var isFirstLevel = false;
			if (rootId === childParentId)
			{
				isFirstLevel = true;
			}
			// repeat and grab all the children of the current element
			// to perform the toggle
			toggleState(currentChild, state, isFirstLevel, rootId);
		}
	}
}


document.addEventListener("DOMContentLoaded", function(event) 
{
	var table = document.getElementById("tableId");
	var classes = table.getElementsByClassName("expandable");

	// init the first row tabs by spacing the childrens
    //var dataLevels= table.querySelectorAll('expandable');
	
	for (var i = 0; i < classes.length; i++) 
	{
		var parent = classes[i].getAttribute('data-parent');
		var level = classes[i].getAttribute('data-level');
		var firstChild = classes[i].firstElementChild;
		
		if (level !== 'undefined' && level !== '1'){
			classes[i].style.display = "none";
		}
		
		if (firstChild !== 'undefined'){
			firstChild.style.paddingLeft = (level * 16) + "px";
		}
	}
});

function collectionHas(a, b) { //helper function (see below)
    for(var i = 0, len = a.length; i < len; i ++) {
        if(a[i] == b) return true;
    }
    return false;
}
function findParentBySelector(elm, selector) {
    var all = document.querySelectorAll(selector);
    var cur = elm.parentNode;
    while(cur && !collectionHas(all, cur)) { //keep going up until you find a match
        cur = cur.parentNode; //go up
    }
    return cur; //will return null if not found
}