const STRING_NONE = 'none';
const STRING_EMPTY = '';

function collapse(parentId) 
{
	var parentEl = document.querySelector('[data-id="' + parentId + '"]');
	var state = parseInt(parentEl.dataset.state) === 1 ? 0 : 1;
	parentEl.dataset.state = state;
	parentEl.dataset.visible = 1;
	
	var el = parentEl.children[0].children[0];
	if (state === 1)
	{
		el.innerHTML='-';
	}
	else
	{
		el.innerHTML='+';
	}
	
	collapseR(parentEl, state);
}

function collapseR(parentEl, expanded)
{
	// get the list of elements who has the matching parent ID
	var children = document.querySelectorAll('[data-parent="' + parentEl.dataset.id + '"]');
	
	if (children.length === 0)
	{
		return;
	}
	
	var parentData = parentEl.dataset;
	
	// ensure the list is not empty
	// loop through those elements (they are considered children)
	for (var i = 0; i < children.length; ++i)
	{
		var child = children[i];
		// get the current syle
		var childStyle = child.style;
		// default drill value
		var drill = true;

		// collapse all
		if (expanded === 0) // case 1
		{
			if (child.dataset.visible === '1') // update only if its not already collapsed
			{
				// only update the visibility
				child.dataset.visible = 0;
				childStyle.display = STRING_NONE;
			}
			else
			{
				// don't drill if the child is already collapsed
				drill = false;
			}
		}
		else
		{
			if (parentData.state === '1' && parentData.visible === '1')
			{
				child.dataset.visible = expanded;
				childStyle.display = STRING_EMPTY;
			}
			else
			{
				// don't drill if the child is already collapsed
				drill = false;
			}
		}
		
		// ensure the child has an ID and we're good to drill further
		if (!!child.dataset.id && drill === true)
		{
			// repeat and grab all the children of the current element
			// to perform the toggle
			collapseR(child, expanded);
		}
	}
}

function accordionDebug(tableId, parentId, depth)
{
	var table = document.getElementById(tableId);
	var tableIdCounter = +parentId;
	var lastParent = tableIdCounter;
	
	for (var i = 0 ; i < depth + 1; i++)
	{
		var row = table.insertRow(-1); // append entry to table
		
		if (i === 0)
		{
			row.dataset.parent=0;
			row.dataset.visible=1;
		}
		else
		{
			row.dataset.parent=lastParent;
			row.dataset.visible=0;
		}
		row.dataset.level=i;
		row.dataset.id=tableIdCounter;
		row.dataset.state=0;
		
		var col1 = row.insertCell(0);
		var col2 = row.insertCell(1);
		var col3 = row.insertCell(2);
		
		col1.innerHTML = '<a href="#" onClick="collapse(' + tableIdCounter + ')">+</a> <a href="#">Entry' + tableIdCounter + '</a>';
		col2.innerHTML = "000,000";
		col3.innerHTML = "<button>Reply</button>";
		
		lastParent=tableIdCounter;
		tableIdCounter++;
	}
}

function accordionInit(tableID)
{
	accordionDebug(tableID, 777, 999);
	accordionDebug(tableID, 888, 999);
	
	var table = document.getElementById(tableID);
	var rows = table.rows
	
	for (var i = 1; i < rows.length; i++) 
	{
		var clazz = rows[i];
		var level = clazz.getAttribute('data-level');
		var firstChild = clazz.firstElementChild;
		
		if (level !== 'undefined' && level !== '0'){
			clazz.style.display = 'none';
			clazz.dataset.visible = 0;
		}
		
		if (firstChild !== 'undefined'){
			firstChild.style.paddingLeft = (level * 16) + "px";
		}
	}
}

document.addEventListener("DOMContentLoaded", function(event) 
{
	accordionInit('tableId');
});