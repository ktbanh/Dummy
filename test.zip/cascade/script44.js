function toggleId(parentId) {
	var parentEl = document.querySelector('[data-id="' + parentId + '"]');
	var state = parseInt(parentEl.dataset.state)
	// toggle the state
	if (state === 1) {
		state=0;
	}
	else {
		state=1;
	}

	// update the state
	parentEl.dataset.state = state;
	parentEl.dataset.prev = state;
	// update the visibility state (always since its being focused)
	parentEl.dataset.visible = 1;
	
	console.log("toggled [parent: " + parentId + ",value:" + state + "]");

	// DEBUG
	parentEl.children[1].innerHTML = "currentState: " + parentEl.dataset.state + " visible: " +  parentEl.dataset.visible + " prev: " + parentEl.dataset.prev;
	
	console.log("----------------------------------------------");
	// perform the toggle
	toggleState(parentEl, state, parentId, true);
	console.log("----------------------------------------------");
}

function toggleState(parentEl, state, rootId, firstLevel)
{
	// get the list of elements who has the matching parent ID
	var children = document.querySelectorAll('[data-parent="' + parentEl.dataset.id + '"]');
	
	if (children.length == 0)
	{
		return;
	}
	// ensure the list is not empty
	// loop through those elements (they are considered children)
	for (var i = 0; i < children.length; ++i)
	{
		var currentChild = children[i];
		// get the current syle
		var currentChildStyle = currentChild.style;
		
		var id = currentChild.dataset.id;
		
		// collapse all, store current states
		if (state === 0) // case 1
		{
			if (id === '10')
			console.log("from case 1");
			currentChild.dataset.prev = currentChild.dataset.visible;
			currentChild.dataset.visible = state;
			currentChildStyle.display = "none";
		}
		else if (firstLevel === true) // case 2
		{
			if (id === '10')
			console.log("from case 1");
			currentChild.dataset.visible = state;
			currentChildStyle.display = "";
			currentChild.dataset.prev = 1;
		}
		else
		{
			if (id === '10')
			console.log("from case 3");
			var previous = currentChild.dataset.prev;
			
			if (currentChild.dataset.visible === '1')
			{
				if (id === '10')
				console.log("from case 3a");
				currentChild.dataset.prev = 1;
				currentChild.dataset.visible = 1;
				currentChildStyle.display = "";
			}
			else if (previous)
			{
				if (id === '10')
				console.log("from case 3b");
				previousState = parseInt(previous);
				
				if (previousState === 1)
				{
					if (id === '10')
					console.log("from case 3ba");
					currentChild.dataset.prev = 1;
					currentChild.dataset.visible = 1;
					currentChildStyle.display = "";
				}
				else if (previousState === 0)
				{
					if (id === '10')
					console.log("from case 3bb");
					currentChild.dataset.prev = 0;
					currentChild.dataset.visible = 0;
					currentChildStyle.display = "none";
				}
				
				
			}
		}
	}
	
	// DEBUG
	console.log(currentChild.dataset.id + " - currentState: " + currentChild.dataset.state + " visible: " +  currentChild.dataset.visible + " prev: " + currentChild.dataset.prev);
	currentChild.children[1].innerHTML = "currentState: " + currentChild.dataset.state + " visible: " +  currentChild.dataset.visible + " prev: " + currentChild.dataset.prev;

	for (var i = 0; i < children.length; ++i)
	{
		var currentChild = children[i];
		// ensure the child has an ID
		if (!!currentChild.dataset.id )
		{
			// repeat and grab all the children of the current element
			// to perform the toggle
			toggleState(currentChild, state, rootId, false);
		}
	}
}


document.addEventListener("DOMContentLoaded", function(event) 
{
	var table = document.getElementById("tableId");
	var classes = table.getElementsByClassName("expandable");

	// init the first row tabs by spacing the childrens
    //var dataLevels= table.querySelectorAll('expandable');
	
	for (var i = 0; i < classes.length; i++) 
	{
		var parent = classes[i].getAttribute('data-parent');
		var level = classes[i].getAttribute('data-level');
		var firstChild = classes[i].firstElementChild;
		
		if (level !== 'undefined' && level !== '1'){
			classes[i].style.display = "none";
		}
		
		if (firstChild !== 'undefined'){
			firstChild.style.paddingLeft = (level * 16) + "px";
		}
	}
});

function collectionHas(a, b) { //helper function (see below)
    for(var i = 0, len = a.length; i < len; i ++) {
        if(a[i] == b) return true;
    }
    return false;
}
function findParentBySelector(elm, selector) {
    var all = document.querySelectorAll(selector);
    var cur = elm.parentNode;
    while(cur && !collectionHas(all, cur)) { //keep going up until you find a match
        cur = cur.parentNode; //go up
    }
    return cur; //will return null if not found
}